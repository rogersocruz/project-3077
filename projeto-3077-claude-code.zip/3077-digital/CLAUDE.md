# PROJETO 3077 — Instruções do projeto para o Claude Code

Jogo digital 3D (três dimensões) de tabuleiro e cartas, adaptação do board game 4X
"Projeto 3077". Leia este arquivo inteiro no início de toda sessão.

## Documentos de referência (ler conforme a fase)
- `docs/GDD.md` — regras completas. **Autoridade sobre regras.**
- `docs/DECISOES_ABERTAS.md` — conflitos resolvidos e decisões em aberto. **Nunca
  resolver sozinho um item em aberto**: usar o valor provisório e deixar configurável.
- `docs/ART_DIRECTION.md` — paleta, tipografia, anatomia da carta, estilo 3D, animação.
- `docs/UX_SPEC.md` — telas, HUD, configurações, atalhos, animações, diálogos, tutorial.
- `docs/PROMPTS.md` — roteiro de fases. Trabalhar **uma fase por sessão**.
- `data/*.json` — **fonte da verdade de todos os números e conteúdos.**

## Stack (fixa — não trocar sem pedir)
| Camada | Tecnologia |
|---|---|
| Linguagem | TypeScript em modo `strict` |
| Build / dev server | Vite |
| Interface 2D | React + CSS Modules, tokens de tema em `src/ui/theme/tokens.ts` |
| Cena 3D | three.js via React Three Fiber, `@react-three/drei`, `@react-three/postprocessing` |
| Estado de interface | Zustand |
| Animação | GSAP (3D e DOM), com timelines orquestradas pelo diretor de animação |
| Validação de dados | Zod (esquemas para cada `data/*.json`) |
| Internacionalização | i18next + react-i18next (pt-BR padrão, en) |
| Áudio | Howler.js; efeitos substitutos gerados com jsfxr |
| Testes | Vitest (motor, IA), Playwright (fluxos e capturas de tela) |
| Qualidade | ESLint + Prettier |
| App desktop (fase final) | Tauri |

Usar as versões estáveis atuais de cada pacote no momento da instalação.

## Arquitetura
```
src/
  engine/        Motor de regras PURO: sem React, sem three, sem DOM, sem Math.random
    state.ts       Tipos do estado da partida
    actions.ts     União discriminada de todas as ações de jogador
    reducer.ts     applyAction(state, action) → { state, events[] }
    phases.ts      Máquina de fases da rodada e do turno
    legal.ts       Geração de ações legais (usada pela UI e pela IA)
    rules/         economy, build, cards, permanents, events, hazards, combat, treaties, victory
    effects/       registry.ts: effectId → handler (cada carta/evento/hazard)
    hex.ts         Matemática axial (q, r), vizinhança, distância, raio, layout de roseta
    rng.ts         RNG (gerador de números aleatórios) com seed (mulberry32 ou similar)
    setup.ts       Montagem determinística da partida a partir da seed
  ai/            Agentes heurísticos (fácil/normal/difícil), só consomem legal.ts
  sim/           Simulador sem renderização (CLI `npm run sim`) para o Laboratório
  data/          Carregamento + esquemas Zod dos JSON da raiz `data/`
  render3d/      Cena: Table, Board, HexTile, Structure, Troop, Token, CardMesh, CameraRig, Fx
  anim/          Diretor de animação: consome eventos do motor → timelines GSAP
  ui/            Telas, HUD, modais, componentes; `ui/card/Card.tsx` gera a face em SVG
  audio/         Gerenciador de som, mapa evento → som
  i18n/          pt-BR.json, en.json
  save/          Salvamento = seed + versão das regras + log de ações
  settings/      Configurações persistidas (localStorage no navegador)
```

### Regras de arquitetura (não negociáveis)
1. **O motor é puro e determinístico.** Mesma seed + mesmo log de ações = mesmo
   estado, sempre. Toda aleatoriedade passa por `engine/rng.ts`.
2. **O motor nunca espera animação.** Ele aplica a ação e emite `events[]`. O diretor de
   animação toca os eventos; a interface bloqueia entrada enquanto há fila.
3. **Nenhum número de regra no código.** Tudo vem de `data/balance.json` e dos JSON.
4. **Nenhum texto visível no código.** Tudo vem de `src/i18n/*.json`.
5. **A interface e a IA perguntam ao `legal.ts`** o que é permitido. Nenhuma regra é
   reimplementada na interface.
6. **Toda carta, evento e hazard é um `effectId`** registrado em `engine/effects/`. Um
   `effectId` desconhecido falha no carregamento dos dados, não no meio da partida.
7. **Arte ausente nunca quebra o jogo**: substituto procedural no estilo.

## Convenções
- Código e identificadores em inglês; textos de jogo em PT-BR via i18n.
- Componentes React pequenos; lógica fora de componentes.
- Cada regra nova vem com teste no Vitest citando a seção do GDD.
- Nada de `any`. Nada de `Math.random` fora de `rng.ts`.
- Cores só via tokens de tema (`ART_DIRECTION.md` seção 2).

## Comandos
```
npm run dev          servidor de desenvolvimento
npm run build        build de produção
npm run test         Vitest
npm run test:e2e     Playwright
npm run lint         ESLint
npm run sim -- --games 200 --players 4 --seed 1   simulação sem renderização
npm run data:check   valida data/*.json contra os esquemas e effectIds
npm run art:check    lista arte faltante do manifesto
```

## Como trabalhar
- Comece cada fase em **modo de planejamento**: leia os documentos da fase, proponha o
  plano, espere aprovação.
- Ao terminar: rode testes, lint e `data:check`; para mudanças visuais, rode o
  Playwright, **tire capturas de tela e olhe para elas** antes de declarar pronto.
- Atualize a seção "Estado atual" abaixo e faça um commit por fase.
- Se uma regra do GDD parecer contraditória, **pare e pergunte** — não invente.

## Estado atual
- Fase concluída: nenhuma
- Próxima fase: 0 — Fundação
- Observações: —
